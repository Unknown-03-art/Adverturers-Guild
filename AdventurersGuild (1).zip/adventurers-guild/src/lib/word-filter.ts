// Stronger automatic word filter for AdventurersGuild
// Blocks nudity, bullying, discrimination, and non-Christian religious promotion

const FORBIDDEN_PATTERNS: RegExp[] = [
  // Nudity / sexual
  /\b(nude|nudity|naked|porn|porno|xxx|sex|sexual|onlyfans|nsfw)\b/i,
  // Strong profanity (basic list)
  /\b(fuck|shit|bitch|asshole|cunt|dick|pussy)\b/i,
  // Bullying / hate
  /\b(kill yourself|kys|retard|faggot|nigger|nigga|tranny)\b/i,
  // Other gods / religions (as requested by Guild Master)
  /\b(allah|muhammad|buddha|krishna|shiva|vishnu|zeus|odin|thor|satan|lucifer|hindu|islam|muslim|allah|jewish|judaism|pagan|wicca|atheist)\b/i,
];

export function containsForbiddenContent(text: string): boolean {
  return FORBIDDEN_PATTERNS.some((pattern) => pattern.test(text));
}

export function getFilterReason(text: string): string | null {
  if (/\b(nude|nudity|naked|porn|porno|xxx|sex|sexual|onlyfans|nsfw)\b/i.test(text)) {
    return "Nudity / sexual content is strictly forbidden. Instant permanent ban.";
  }
  if (/\b(kill yourself|kys|retard|faggot|nigger|nigga|tranny)\b/i.test(text)) {
    return "Bullying / hate speech is not allowed.";
  }
  if (/\b(allah|muhammad|buddha|krishna|shiva|vishnu|zeus|odin|thor|satan|lucifer|hindu|islam|muslim|jewish|judaism|pagan|wicca|atheist)\b/i.test(text)) {
    return "Only the gospel of Jesus Christ is allowed in this guild.";
  }
  if (/\b(fuck|shit|bitch|asshole|cunt|dick|pussy)\b/i.test(text)) {
    return "Excessive profanity is not allowed.";
  }
  return null;
}
