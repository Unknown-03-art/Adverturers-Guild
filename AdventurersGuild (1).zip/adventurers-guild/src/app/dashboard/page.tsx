"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile, RANK_NAMES } from "@/lib/supabase";
import Link from "next/link";

export default function DashboardPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const { data } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (!data) {
        router.push("/login");
        return;
      }

      setProfile(data);
      setLoading(false);
    };
    load();
  }, [router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">Dashboard</h1>
          <button
            onClick={async () => {
              await supabase.auth.signOut();
              router.push("/");
            }}
            className="text-sm text-gray-400 hover:text-red-400"
          >
            Logout
          </button>
        </div>

        {/* Profile Card */}
        <div className="bg-[#141414] border border-[#2a2a2a] rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-[#0a0a0a] border-2 border-[#d4af37]/50 flex items-center justify-center text-2xl font-bold text-[#d4af37]">
              AG
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">{profile?.in_game_name}</h2>
              <p className="text-sm text-[#d4af37]">
                {RANK_NAMES[profile?.rank ?? 5]} (Rank {profile?.rank})
              </p>
              <p className="text-xs text-gray-500">{profile?.email}</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid gap-3">
          <Link
            href="/chat"
            className="block bg-[#141414] border border-[#2a2a2a] hover:border-[#d4af37]/50 rounded-xl p-4 transition"
          >
            <div className="font-semibold text-white">Open World Chat</div>
            <div className="text-sm text-gray-400">Talk with members across the world</div>
          </Link>

          {(profile?.rank ?? 5) <= 3 && (
            <Link
              href="/private-chat"
              className="block bg-[#141414] border border-[#2a2a2a] hover:border-red-500/50 rounded-xl p-4 transition"
            >
              <div className="font-semibold text-red-300">Leadership Private Chat</div>
              <div className="text-sm text-gray-400">Rank 0–3 only</div>
            </Link>
          )}

          {(profile?.rank ?? 5) <= 2 && (
            <Link
              href="/admin"
              className="block bg-[#141414] border border-[#2a2a2a] hover:border-[#d4af37]/50 rounded-xl p-4 transition"
            >
              <div className="font-semibold text-white">Membership Requests</div>
              <div className="text-sm text-gray-400">Review and approve new members</div>
            </Link>
          )}

          <Link
            href="/clans"
            className="block bg-[#141414] border border-[#2a2a2a] hover:border-[#d4af37]/50 rounded-xl p-4 transition"
          >
            <div className="font-semibold text-white">Clans</div>
            <div className="text-sm text-gray-400">Create or join a clan (max 25 members)</div>
          </Link>

          <Link
            href="/shop"
            className="block bg-[#141414] border border-[#2a2a2a] hover:border-[#d4af37]/50 rounded-xl p-4 transition"
          >
            <div className="font-semibold text-white">Guild Shop</div>
            <div className="text-sm text-gray-400">Frames, clan creation & more</div>
          </Link>

          <Link
            href="/gifts"
            className="block bg-[#141414] border border-[#2a2a2a] hover:border-[#d4af37]/50 rounded-xl p-4 transition"
          >
            <div className="font-semibold text-white">Gifts</div>
            <div className="text-sm text-gray-400">Send coupons or real money via PayPal</div>
          </Link>
        </div>
      </div>
    </div>
  );
}
