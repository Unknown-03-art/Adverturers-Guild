"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";

function SetPasswordForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // Supabase recovery / invite tokens come in the URL hash or query
  useEffect(() => {
    // Listen for auth state changes (invite / recovery)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") {
        // ready to set password
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  const handleSetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    const { error } = await supabase.auth.updateUser({ password });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    setSuccess(true);
    setTimeout(() => router.push("/dashboard"), 2000);
  };

  if (success) {
    return (
      <div className="text-center space-y-4">
        <div className="text-5xl">✅</div>
        <h2 className="text-2xl font-bold text-[#d4af37]">Password Set!</h2>
        <p className="text-gray-400">Redirecting you to the guild...</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSetPassword} className="space-y-4">
      <div>
        <label className="block text-sm text-gray-300 mb-1">New Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={8}
          placeholder="At least 8 characters"
          className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
        />
      </div>
      <div>
        <label className="block text-sm text-gray-300 mb-1">Confirm Password</label>
        <input
          type="password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          required
          className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
        />
      </div>

      {error && <p className="text-red-400 text-sm text-center">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] hover:from-[#e0c040] hover:to-[#c9a70e] transition disabled:opacity-60"
      >
        {loading ? "Saving..." : "Set Password & Enter Guild"}
      </button>
    </form>
  );
}

export default function SetPasswordPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] px-4">
      <div className="w-full max-w-md bg-[#141414] border border-[#2a2a2a] rounded-2xl p-8">
        <h1 className="text-2xl font-bold text-center text-[#d4af37] mb-2">
          Create Your Password
        </h1>
        <p className="text-center text-gray-400 text-sm mb-6">
          Welcome to AdventurersGuild! Set a private password that only you will know.
        </p>
        <Suspense fallback={<p className="text-center text-gray-400">Loading...</p>}>
          <SetPasswordForm />
        </Suspense>
      </div>
    </div>
  );
}
