"use client";

import { useState } from "react";
import Image from "next/image";
import { supabase } from "@/lib/supabase";

export default function Home() {
  const [formData, setFormData] = useState({
    inGameName: "",
    email: "",
    age: "",
    favGame1: "",
    favGame2: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Basic validation
    if (
      !formData.inGameName.trim() ||
      !formData.email.trim() ||
      !formData.age ||
      !formData.favGame1.trim() ||
      !formData.favGame2.trim()
    ) {
      setError("All fields are required.");
      setLoading(false);
      return;
    }
    const ageNum = parseInt(formData.age, 10);
    if (isNaN(ageNum) || ageNum < 13 || ageNum > 99) {
      setError("Age must be between 13 and 99.");
      setLoading(false);
      return;
    }
    if (!formData.email.includes("@")) {
      setError("Please enter a valid email.");
      setLoading(false);
      return;
    }

    try {
      const { error: insertError } = await supabase.from("membership_requests").insert({
        in_game_name: formData.inGameName.trim(),
        email: formData.email.trim().toLowerCase(),
        age: ageNum,
        fav_game_1: formData.favGame1.trim(),
        fav_game_2: formData.favGame2.trim(),
        status: "pending",
      });

      if (insertError) {
        console.error(insertError);
        setError("Could not submit request. Please try again later.");
        setLoading(false);
        return;
      }

      setSubmitted(true);
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12 bg-[#0a0a0a]">
        <div className="max-w-md w-full text-center space-y-6">
          <div className="text-6xl mb-4">⚔️</div>
          <h1 className="text-3xl font-bold text-[#d4af37]">Request Received</h1>
          <p className="text-gray-300 leading-relaxed">
            Your request to join{" "}
            <span className="text-[#d4af37] font-semibold">AdventurersGuild</span> has
            been submitted.
          </p>
          <p className="text-gray-400 text-sm">
            The Guild Master, Elders or General Commanders will review it soon. You
            will receive an email once a decision is made.
          </p>
          <p className="text-gray-500 text-xs mt-8">
            “Let’s enjoy our interaction moments and have fun.”
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-10 bg-[#0a0a0a]">
      {/* Logo Area */}
      <div className="mb-8 text-center">
        <div className="mx-auto w-52 h-52 md:w-64 md:h-64 relative rounded-2xl overflow-hidden border-2 border-[#d4af37]/40 shadow-2xl shadow-[#d4af37]/15">
          {/* Place your generated logo as public/logo.png */}
          <Image
            src="/logo.png"
            alt="AdventurersGuild Logo"
            fill
            className="object-cover"
            priority
            onError={(e) => {
              // Fallback if logo.png is missing
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
          {/* Fallback text logo if image not found */}
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-[#1a1a1a] to-[#0a0a0a]">
            <div className="text-center">
              <div className="text-5xl md:text-6xl font-black tracking-tighter">
                <span className="text-[#d4af37]">A</span>
                <span className="text-gray-200">G</span>
              </div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-[#d4af37]/80 mt-1">
                Adventurers Guild
              </div>
            </div>
          </div>
        </div>
        <p className="mt-4 text-sm text-gray-400 max-w-xs mx-auto">
          The global platform for gamers. Request to join the guild.
        </p>
      </div>

      {/* Request Form Card */}
      <div className="w-full max-w-md bg-[#141414] border border-[#2a2a2a] rounded-2xl p-6 md:p-8 shadow-xl">
        <h1 className="text-2xl font-bold text-center mb-1 text-white">
          Request Membership
        </h1>
        <p className="text-center text-gray-400 text-sm mb-6">
          Fill in the details below. Approval required by Guild Master, Elders or
          General Commanders.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="inGameName"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              In-Game Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="inGameName"
              name="inGameName"
              value={formData.inGameName}
              onChange={handleChange}
              placeholder="Your main in-game name"
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] transition"
              required
            />
          </div>

          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] transition"
              required
            />
          </div>

          <div>
            <label
              htmlFor="age"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              Age <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={handleChange}
              placeholder="13+"
              min="13"
              max="99"
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] transition"
              required
            />
          </div>

          <div>
            <label
              htmlFor="favGame1"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              Favourite Game 1 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="favGame1"
              name="favGame1"
              value={formData.favGame1}
              onChange={handleChange}
              placeholder="e.g. Valorant, Genshin Impact, WoW..."
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] transition"
              required
            />
          </div>

          <div>
            <label
              htmlFor="favGame2"
              className="block text-sm font-medium text-gray-300 mb-1"
            >
              Favourite Game 2 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="favGame2"
              name="favGame2"
              value={formData.favGame2}
              onChange={handleChange}
              placeholder="Another game you love"
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] transition"
              required
            />
          </div>

          {error && (
            <p className="text-red-400 text-sm text-center">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3.5 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] hover:from-[#e0c040] hover:to-[#c9a70e] transition shadow-lg shadow-[#d4af37]/20 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading ? "Submitting..." : "Submit Request"}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-gray-500 leading-relaxed">
          By submitting you agree to the Guild Rules:
          <br />
          No nudity • No bullying • No discrimination
          <br />
          Only the gospel of Jesus Christ is allowed.
        </p>

        <p className="mt-4 text-center text-sm text-gray-400">
          Already a member?{" "}
          <a href="/login" className="text-[#d4af37] hover:underline">
            Login here
          </a>
        </p>
      </div>

      <footer className="mt-10 text-center text-xs text-gray-600">
        © {new Date().getFullYear()} AdventurersGuild • Rank 0:{" "}
        <span className="font-bold text-black bg-gradient-to-r from-red-800 to-black text-transparent bg-clip-text outline-white">
          🎭 UNKNOWN🎭
        </span>
      </footer>
    </div>
  );
}
