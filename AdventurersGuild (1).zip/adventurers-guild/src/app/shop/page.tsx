"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile } from "@/lib/supabase";
import Link from "next/link";

const FRAMES = [
  { id: "default", name: "Default AG", price: 0, description: "Free standard frame" },
  { id: "gold", name: "Gold Frame", price: 100, description: "Shiny gold border – $1" },
  { id: "mystic", name: "Mystic Crown", price: 100, description: "For Elders – $1" },
  { id: "legendary", name: "Legendary Crown", price: 100, description: "For Elders – $1" },
  { id: "unique", name: "Unique Crown", price: 100, description: "For Elders – $1" },
  { id: "commander", name: "Commander Frame", price: 100, description: "Special commander style – $1" },
];

export default function ShopPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (!data) {
        router.push("/login");
        return;
      }
      setProfile(data);
      setLoading(false);
    };
    load();
  }, [router]);

  const handleBuyFrame = async (frameId: string, priceCents: number) => {
    if (!profile) return;

    if (priceCents === 0) {
      // Free frame
      await supabase.from("profiles").update({ frame: frameId }).eq("id", profile.id);
      setMessage("Frame updated!");
      setProfile({ ...profile, frame: frameId });
      return;
    }

    // Record pending purchase – real PayPal/Stripe integration comes next
    const { error } = await supabase.from("purchases").insert({
      user_id: profile.id,
      item_type: "frame",
      item_id: frameId,
      amount_cents: priceCents,
      payment_provider: "paypal",
      status: "pending",
    });

    if (error) {
      setMessage("Could not start purchase. Try again.");
      return;
    }

    // For now show instructions (real PayPal button needs your PayPal client ID)
    setMessage(
      `Purchase recorded ($${priceCents / 100}). ` +
      `To complete payment, send $${priceCents / 100} via PayPal to the Guild Master and message them your in-game name. ` +
      `After confirmation your frame will be activated.`
    );
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">Loading shop...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">Guild Shop</h1>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">
            {message}
          </div>
        )}

        <h2 className="text-lg font-semibold mb-4 text-white">Profile Frames ($1 each)</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {FRAMES.map((frame) => (
            <div key={frame.id} className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center text-lg font-bold
                  ${frame.id === "gold" ? "border-yellow-500 text-yellow-400" :
                    frame.id.includes("crown") || frame.id === "mystic" || frame.id === "legendary" || frame.id === "unique" ? "border-purple-500 text-purple-300" :
                    frame.id === "commander" ? "border-red-500 text-red-300" :
                    "border-[#d4af37] text-[#d4af37]"}`}>
                  AG
                </div>
                <div>
                  <p className="font-semibold text-white">{frame.name}</p>
                  <p className="text-xs text-gray-400">{frame.description}</p>
                </div>
              </div>
              <button
                onClick={() => handleBuyFrame(frame.id, frame.price)}
                disabled={profile?.frame === frame.id}
                className="w-full py-2.5 rounded-lg font-medium text-sm transition
                  disabled:opacity-50 disabled:cursor-not-allowed
                  bg-gradient-to-r from-[#d4af37] to-[#b8960c] text-black hover:from-[#e0c040] hover:to-[#c9a70e]"
              >
                {profile?.frame === frame.id ? "Equipped" : frame.price === 0 ? "Use Free" : `Buy for $${frame.price / 100}`}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-10 bg-[#141414] border border-[#2a2a2a] rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-2">Create a Clan – $5</h2>
          <p className="text-sm text-gray-400 mb-4">
            Max 25 members. Levels up from 1 to 10 based on members and contribution.
            Max-level clans unlock all paid equipment.
          </p>
          <Link
            href="/clans"
            className="inline-block px-6 py-3 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] hover:from-[#e0c040] hover:to-[#c9a70e] transition"
          >
            Go to Clans
          </Link>
        </div>

        <p className="mt-8 text-xs text-gray-600 text-center">
          Payments currently manual via PayPal (preferred). Full automated PayPal + Stripe integration can be added once you provide merchant accounts.
        </p>
      </div>
    </div>
  );
}
