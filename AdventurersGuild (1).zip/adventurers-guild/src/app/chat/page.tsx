"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { supabase, ChatMessage, Profile, RANK_NAMES } from "@/lib/supabase";
import Link from "next/link";

export default function ChatPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (!profileData) {
        router.push("/login");
        return;
      }
      setProfile(profileData);

      // Load recent messages
      const { data: msgs } = await supabase
        .from("chat_messages")
        .select("*")
        .order("created_at", { ascending: true })
        .limit(100);

      setMessages(msgs || []);
      setLoading(false);

      // Realtime subscription
      const channel = supabase
        .channel("open-world-chat")
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "chat_messages" },
          (payload) => {
            setMessages((prev) => [...prev, payload.new as ChatMessage]);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    };

    init();
  }, [router]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !profile) return;

    const { containsForbiddenContent, getFilterReason } = await import("@/lib/word-filter");
    if (containsForbiddenContent(newMessage)) {
      alert(getFilterReason(newMessage) || "Message blocked by Guild rules.");
      return;
    }

    const { error } = await supabase.from("chat_messages").insert({
      user_id: profile.id,
      in_game_name: profile.in_game_name,
      rank: profile.rank,
      message: newMessage.trim(),
    });

    if (!error) {
      setNewMessage("");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">
        Loading chat...
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a]">
      {/* Header */}
      <header className="border-b border-[#2a2a2a] px-4 py-3 flex items-center justify-between bg-[#0f0f0f]">
        <div>
          <h1 className="text-lg font-bold text-[#d4af37]">Open World Chat</h1>
          <p className="text-xs text-gray-500">
            Logged in as {profile?.in_game_name} ({RANK_NAMES[profile?.rank ?? 5]})
          </p>
        </div>
        <div className="flex gap-3">
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">
            Dashboard
          </Link>
          <button
            onClick={async () => {
              await supabase.auth.signOut();
              router.push("/");
            }}
            className="text-sm text-gray-400 hover:text-red-400"
          >
            Logout
          </button>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-center text-gray-600 py-10">No messages yet. Say hello!</p>
        )}
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.user_id === profile?.id ? "items-end" : "items-start"
            }`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                msg.user_id === profile?.id
                  ? "bg-[#d4af37]/20 border border-[#d4af37]/30"
                  : "bg-[#1a1a1a] border border-[#2a2a2a]"
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`text-xs font-semibold ${
                    msg.rank === 0
                      ? "text-red-400"
                      : msg.rank <= 2
                      ? "text-[#d4af37]"
                      : "text-gray-400"
                  }`}
                >
                  {msg.in_game_name}
                </span>
                <span className="text-[10px] text-gray-600">
                  {RANK_NAMES[msg.rank] || "Member"}
                </span>
              </div>
              <p className="text-sm text-gray-100 whitespace-pre-wrap break-words">
                {msg.message}
              </p>
              <p className="text-[10px] text-gray-600 mt-1 text-right">
                {new Date(msg.created_at).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form
        onSubmit={sendMessage}
        className="border-t border-[#2a2a2a] p-4 bg-[#0f0f0f] flex gap-3"
      >
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
          maxLength={1000}
          className="flex-1 px-4 py-3 rounded-xl bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-[#d4af37]"
        />
        <button
          type="submit"
          className="px-6 py-3 rounded-xl font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] hover:from-[#e0c040] hover:to-[#c9a70e] transition"
        >
          Send
        </button>
      </form>
    </div>
  );
}
