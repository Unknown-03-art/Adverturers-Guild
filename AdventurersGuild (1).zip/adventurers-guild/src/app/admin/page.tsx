"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, MembershipRequest, Profile, RANK_NAMES } from "@/lib/supabase";
import Link from "next/link";

export default function AdminPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [requests, setRequests] = useState<MembershipRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (!profileData || profileData.rank > 2) {
        router.push("/dashboard");
        return;
      }

      setProfile(profileData);
      await fetchRequests();
      setLoading(false);
    };
    init();
  }, [router]);

  const fetchRequests = async () => {
    const { data, error } = await supabase
      .from("membership_requests")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: false });

    if (!error) {
      setRequests(data || []);
    }
  };

  const handleAction = async (req: MembershipRequest, status: "approved" | "rejected") => {
    if (!profile) return;
    setActionLoading(req.id);
    setMessage("");

    const { error: updateError } = await supabase
      .from("membership_requests")
      .update({
        status,
        reviewed_by: profile.in_game_name,
        updated_at: new Date().toISOString(),
      })
      .eq("id", req.id);

    if (updateError) {
      setMessage("Failed to update request.");
      setActionLoading(null);
      return;
    }

    if (status === "approved") {
      // Create account – Supabase will send confirmation email
      // User will then set their own password via the link
      const tempPassword = Math.random().toString(36).slice(-12) + "Ag1!";

      const { error: authError } = await supabase.auth.signUp({
        email: req.email,
        password: tempPassword,
        options: {
          data: {
            in_game_name: req.in_game_name,
            rank: 5,
          },
          emailRedirectTo: `${typeof window !== "undefined" ? window.location.origin : ""}/set-password`,
        },
      });

      if (authError) {
        console.error(authError);
        setMessage(
          `Request approved, but account email failed: ${authError.message}. Create the account manually if needed.`
        );
      } else {
        setMessage(`Approved! An email was sent to ${req.email} so they can set their password.`);
      }
    } else {
      setMessage(`Rejected ${req.in_game_name}.`);
    }

    setRequests((prev) => prev.filter((r) => r.id !== req.id));
    setActionLoading(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-[#d4af37]">Membership Requests</h1>
            <p className="text-sm text-gray-400">
              Logged in as {profile?.in_game_name} ({RANK_NAMES[profile?.rank ?? 5]})
            </p>
          </div>
          <div className="flex gap-3">
            <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">
              Dashboard
            </Link>
            <Link href="/chat" className="text-sm text-gray-400 hover:text-white">
              Chat
            </Link>
          </div>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">
            {message}
          </div>
        )}

        {requests.length === 0 ? (
          <div className="text-center py-20 text-gray-500">
            <p className="text-4xl mb-4">📭</p>
            <p>No pending membership requests.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {requests.map((req) => (
              <div
                key={req.id}
                className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <p className="font-semibold text-lg text-white">{req.in_game_name}</p>
                  <p className="text-sm text-gray-400">{req.email}</p>
                  <p className="text-sm text-gray-400">
                    Age: {req.age} • Games: {req.fav_game_1} & {req.fav_game_2}
                  </p>
                  <p className="text-xs text-gray-600">
                    Requested: {new Date(req.created_at).toLocaleString()}
                  </p>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => handleAction(req, "approved")}
                    disabled={actionLoading === req.id}
                    className="px-5 py-2.5 rounded-lg bg-green-700 hover:bg-green-600 text-white font-medium transition disabled:opacity-50"
                  >
                    {actionLoading === req.id ? "..." : "Accept"}
                  </button>
                  <button
                    onClick={() => handleAction(req, "rejected")}
                    disabled={actionLoading === req.id}
                    className="px-5 py-2.5 rounded-lg bg-red-800 hover:bg-red-700 text-white font-medium transition disabled:opacity-50"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
