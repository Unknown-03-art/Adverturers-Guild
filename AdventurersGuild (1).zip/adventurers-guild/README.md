# AdventurersGuild

Black-themed global gaming guild platform.

## All Features Implemented

- Membership request + leadership approval (Rank 0–2)
- Real authentication + ranks (0 Guild Master → 5 Member)
- Password creation for approved members
- Automatic account email on approval
- Open-world real-time chat
- Leadership private chat (Rank 0–3)
- Clans system (create $5, max 25 members, levels 1–10)
- Guild Shop (profile frames $1, clan creation)
- Gifts system (in-game coupons + real money via PayPal)
- Strong automatic word filter (nudity, bullying, other gods)
- Profile frames
- Ready for Vercel deploy

## Setup (one-time)

### 1. Supabase
1. Create free project at https://supabase.com
2. SQL Editor → paste and run entire `supabase-schema.sql`
3. Authentication → Providers → enable Email
4. Authentication → URL Configuration → add `http://localhost:3000` and your future Vercel URL

### 2. Environment
Create `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Logo
Save the generated AG logo as `public/logo.png`

### 4. Create Guild Master
1. Supabase → Authentication → Users → Add user (your email)
2. Table Editor → profiles → set `rank = 0` and `in_game_name = 🎭 UNKNOWN🎭`

### 5. Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel (free live link)

1. Push the project to a GitHub repository
2. Go to https://vercel.com → New Project → Import the repo
3. Add the same two environment variables
4. Deploy
5. You get a free link like `https://adventurers-guild-xxx.vercel.app`

Later you can add a custom domain in Vercel settings.

## Pages

| Path             | Who can access          | Description                     |
|------------------|-------------------------|---------------------------------|
| `/`              | Everyone                | Request membership              |
| `/login`         | Everyone                | Login                           |
| `/set-password`  | New members             | Create private password         |
| `/dashboard`     | Logged-in members       | Home + navigation               |
| `/chat`          | Logged-in members       | Open-world real-time chat       |
| `/private-chat`  | Rank 0–3                | Leadership private chat         |
| `/admin`         | Rank 0–2                | Approve / reject requests       |
| `/clans`         | Logged-in members       | Create / join clans             |
| `/shop`          | Logged-in members       | Frames + clan creation          |

## Payments note
PayPal is preferred. Currently purchases are recorded as “pending”.  
You (Guild Master) confirm payment manually, then update the purchase status or equip the frame.  
Full automated PayPal / Stripe buttons can be added once you create merchant accounts.

## Ranks

| Rank | Title               | Special powers                     |
|------|---------------------|------------------------------------|
| 0    | Guild Master        | Full control + finance             |
| 1    | Elder (3 spots)     | Promote / demote / kick            |
| 2    | General Commander   | Assign tasks, control              |
| 3    | Commander           | Mediate clans, private chat        |
| 4    | Officer             | Issue warnings                     |
| 5    | Member              | Chat, clans, shop, rate games      |
