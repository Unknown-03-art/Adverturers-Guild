-- =====================================================
-- AdventurersGuild FULL Schema (run entire script)
-- =====================================================

-- 1. Membership requests
create table if not exists public.membership_requests (
  id uuid primary key default gen_random_uuid(),
  in_game_name text not null,
  email text not null,
  age integer not null check (age >= 13 and age <= 99),
  fav_game_1 text not null,
  fav_game_2 text not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  reviewed_by text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_membership_requests_status on public.membership_requests (status);

-- 2. Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  in_game_name text unique not null,
  email text not null,
  rank integer not null default 5 check (rank >= 0 and rank <= 5),
  rank_title text generated always as (
    case rank
      when 0 then 'Guild Master'
      when 1 then 'Elder'
      when 2 then 'General Commander'
      when 3 then 'Commander'
      when 4 then 'Officer'
      else 'Member'
    end
  ) stored,
  avatar_url text,
  frame text default 'default',
  bio text,
  warnings integer default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 3. Open-world chat
create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  in_game_name text not null,
  rank integer not null,
  message text not null check (char_length(message) <= 1000),
  created_at timestamptz not null default now()
);
create index if not exists idx_chat_messages_created on public.chat_messages (created_at desc);

-- 4. Higher-rank private chat (Rank 0-3)
create table if not exists public.private_chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  in_game_name text not null,
  rank integer not null,
  message text not null check (char_length(message) <= 1000),
  created_at timestamptz not null default now()
);
create index if not exists idx_private_chat_created on public.private_chat_messages (created_at desc);

-- 5. Clans
create table if not exists public.clans (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  description text,
  leader_id uuid not null references public.profiles(id),
  level integer not null default 1 check (level >= 1 and level <= 10),
  member_count integer not null default 1 check (member_count <= 25),
  contribution_points integer not null default 0,
  created_at timestamptz not null default now()
);

-- 6. Clan members
create table if not exists public.clan_members (
  id uuid primary key default gen_random_uuid(),
  clan_id uuid not null references public.clans(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('leader', 'officer', 'member')),
  joined_at timestamptz not null default now(),
  unique(clan_id, user_id)
);

-- 7. Shop purchases
create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_type text not null,
  item_id text not null,
  amount_cents integer not null,
  payment_provider text,
  payment_id text,
  status text not null default 'pending' check (status in ('pending', 'completed', 'failed')),
  created_at timestamptz not null default now()
);

-- 8. Enable RLS
alter table public.membership_requests enable row level security;
alter table public.profiles enable row level security;
alter table public.chat_messages enable row level security;
alter table public.private_chat_messages enable row level security;
alter table public.clans enable row level security;
alter table public.clan_members enable row level security;
alter table public.purchases enable row level security;

-- Policies
drop policy if exists "Anyone can submit a request" on public.membership_requests;
create policy "Anyone can submit a request" on public.membership_requests for insert with check (true);

drop policy if exists "Leadership can read requests" on public.membership_requests;
create policy "Leadership can read requests" on public.membership_requests for select
  using (exists (select 1 from public.profiles where id = auth.uid() and rank <= 2));

drop policy if exists "Leadership can update requests" on public.membership_requests;
create policy "Leadership can update requests" on public.membership_requests for update
  using (exists (select 1 from public.profiles where id = auth.uid() and rank <= 2));

drop policy if exists "Public profiles are viewable by everyone" on public.profiles;
create policy "Public profiles are viewable by everyone" on public.profiles for select using (true);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);

drop policy if exists "Users can insert own profile" on public.profiles;
create policy "Users can insert own profile" on public.profiles for insert with check (auth.uid() = id);

drop policy if exists "Authenticated users can read chat" on public.chat_messages;
create policy "Authenticated users can read chat" on public.chat_messages for select using (auth.role() = 'authenticated');

drop policy if exists "Authenticated users can send messages" on public.chat_messages;
create policy "Authenticated users can send messages" on public.chat_messages for insert with check (auth.uid() = user_id);

create policy "High ranks can read private chat" on public.private_chat_messages for select
  using (exists (select 1 from public.profiles where id = auth.uid() and rank <= 3));
create policy "High ranks can send private chat" on public.private_chat_messages for insert
  with check (auth.uid() = user_id and exists (select 1 from public.profiles where id = auth.uid() and rank <= 3));

create policy "Anyone can view clans" on public.clans for select using (true);
create policy "Authenticated can create clan" on public.clans for insert with check (auth.uid() = leader_id);
create policy "Leader can update clan" on public.clans for update using (auth.uid() = leader_id);

create policy "Anyone can view clan members" on public.clan_members for select using (true);
create policy "Users can join clans" on public.clan_members for insert with check (auth.uid() = user_id);

create policy "Users can view own purchases" on public.purchases for select using (auth.uid() = user_id);
create policy "Users can create purchases" on public.purchases for insert with check (auth.uid() = user_id);

-- Trigger
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, in_game_name, email, rank)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'in_game_name', split_part(new.email, '@', 1)),
    new.email,
    coalesce((new.raw_user_meta_data->>'rank')::integer, 5)
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 9. Gifts system
create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  gift_type text not null check (gift_type in ('coupon', 'money')),
  title text not null,
  description text,
  amount_cents integer default 0,          -- for money gifts
  coupon_code text,                        -- for in-game coupons
  status text not null default 'pending' check (status in ('pending', 'sent', 'claimed', 'cancelled')),
  created_at timestamptz not null default now(),
  claimed_at timestamptz
);

alter table public.gifts enable row level security;

create policy "Users can view gifts they sent or received"
  on public.gifts for select
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

create policy "Users can send gifts"
  on public.gifts for insert
  with check (auth.uid() = sender_id);

create policy "Receiver can claim gift"
  on public.gifts for update
  using (auth.uid() = receiver_id);
